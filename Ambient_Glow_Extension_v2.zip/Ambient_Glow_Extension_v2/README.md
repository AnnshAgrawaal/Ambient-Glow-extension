# Ambient Glow for Twitch, YouTube & Kick

One extension, one settings panel, ambient lighting on all three sites.

## Install (unpacked)
1. Unzip this folder.
2. Open chrome://extensions and turn on **Developer mode** (top right).
3. Click **Load unpacked** and select the unzipped folder.
4. Open a supported stream. Click the toolbar icon to tune it.
