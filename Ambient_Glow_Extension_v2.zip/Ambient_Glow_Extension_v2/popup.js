const DEFAULTS = {
  enabled: true, youtube: true, twitch: true, kick: true,
  blur: 70, spread: 35, opacity: 65, brightness: 100, saturation: 130,
  fps: 30, smooth: 40
};

const TOGGLES = [
  ['enabled', 'Ambient glow'],
  ['youtube', 'Enable on YouTube'],
  ['twitch', 'Enable on Twitch'],
  ['kick', 'Enable on Kick']
];

const SLIDERS = [
  ['blur', 'Blur', 0, 200, 1, 'px'],
  ['spread', 'Glow size', 0, 100, 1, '%'],
  ['opacity', 'Opacity', 0, 100, 1, '%'],
  ['brightness', 'Brightness', 50, 200, 1, '%'],
  ['saturation', 'Saturation', 50, 300, 1, '%'],
  ['smooth', 'Smoothing', 0, 90, 1, '%'],
  ['fps', 'Frame rate', 5, 60, 1, ' fps']
];

const togglesEl = document.getElementById('toggles');
const slidersEl = document.getElementById('sliders');
const inputs = {};

function save(key, value) {
  chrome.storage.local.set({ [key]: value });
}

function render(state) {
  for (const [key, label] of TOGGLES) {
    const row = document.createElement('div');
    row.className = 'row';
    row.innerHTML = `<label for="${key}">${label}</label>
      <label class="switch"><input type="checkbox" id="${key}"><span></span></label>`;
    togglesEl.appendChild(row);
    const input = row.querySelector('input');
    input.checked = state[key];
    input.addEventListener('change', () => save(key, input.checked));
    inputs[key] = input;
  }

  for (const [key, label, min, max, step, unit] of SLIDERS) {
    const wrap = document.createElement('div');
    wrap.className = 'slider';
    wrap.innerHTML = `<div class="top"><label for="${key}">${label}</label><span class="val"></span></div>
      <input type="range" id="${key}" min="${min}" max="${max}" step="${step}">`;
    slidersEl.appendChild(wrap);
    const input = wrap.querySelector('input');
    const val = wrap.querySelector('.val');
    const show = () => (val.textContent = input.value + unit);
    input.value = state[key];
    show();
    input.addEventListener('input', () => { show(); save(key, Number(input.value)); });
    inputs[key] = { input, show };
  }
}

chrome.storage.local.get(DEFAULTS, render);

document.getElementById('reset').addEventListener('click', () => {
  chrome.storage.local.set(DEFAULTS, () => {
    for (const [key] of TOGGLES) inputs[key].checked = DEFAULTS[key];
    for (const [key] of SLIDERS) {
      inputs[key].input.value = DEFAULTS[key];
      inputs[key].show();
    }
  });
});