(() => {
  'use strict';

  const SITE = location.hostname.includes('twitch') ? 'twitch' : 
               location.hostname.includes('kick') ? 'kick' : 'youtube';

  const DEFAULTS = {
    enabled: true, youtube: true, twitch: true, kick: true,
    blur: 70,        // px
    spread: 35,      // % of player size added on each side
    opacity: 65,     // %
    brightness: 100, // %
    saturation: 130, // %
    fps: 30,
    smooth: 40       // % frame blending (0 = off)
  };
  const cfg = { ...DEFAULTS };

  // The video frame is downscaled to this tiny size; CSS then stretches + blurs it.
  const SW = 64, SH = 36;

  const root = document.documentElement;
  root.classList.add('al-' + SITE);

  const canvas = document.createElement('canvas');
  canvas.id = 'al-canvas';
  canvas.width = SW;
  canvas.height = SH;
  const ctx = canvas.getContext('2d');
  
  // Append to body instead of root to respect stacking contexts (e.g. Twitch Theater)
  document.body.appendChild(canvas);

  // ---------- settings ----------
  function applyConfig() {
    canvas.style.filter =
      `blur(${cfg.blur}px) brightness(${cfg.brightness}%) saturate(${cfg.saturation}%)`;
    canvas.style.opacity = String(cfg.opacity / 100);
    lastKey = '';
    dirty = true;
  }

  try {
    chrome.storage.local.get(DEFAULTS, (items) => {
      Object.assign(cfg, items);
      applyConfig();
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      for (const k in changes) cfg[k] = changes[k].newValue;
      applyConfig();
    });
  } catch (_) { /* extension was reloaded; page needs a refresh */ }

  // ---------- video tracking ----------
  let video = null, lastPick = 0;
  let dirty = true, fresh = true, lastKey = '', lastDraw = 0;
  let shown = false, wasActive = false;

  const markDirty = () => { dirty = true; };
  const markFresh = () => { dirty = true; fresh = true; };

  function attach(v) {
    if (video) {
      video.removeEventListener('play', markDirty);
      video.removeEventListener('seeked', markFresh);
      video.removeEventListener('loadeddata', markFresh);
    }
    video = v;
    if (v) {
      v.addEventListener('play', markDirty);
      v.addEventListener('seeked', markFresh);
      v.addEventListener('loadeddata', markFresh);
    }
    markFresh();
  }

  // Pick the biggest playing/loaded <video> on the page
  function pickVideo(now) {
    if (video && video.isConnected && now - lastPick < 1000) return video;
    lastPick = now;
    let best = null, bestArea = 0;
    for (const v of document.querySelectorAll('video')) {
      const r = v.getBoundingClientRect();
      const area = r.width * r.height;
      if (v.readyState >= 2 && r.width >= 320 && area > bestArea) {
        best = v;
        bestArea = area;
      }
    }
    if (best !== video) attach(best);
    return video;
  }

  // Rect of the actual picture (excludes letterbox bars)
  function contentRect(v) {
    const r = v.getBoundingClientRect();
    const vw = v.videoWidth, vh = v.videoHeight;
    if (!vw || !vh) return r;
    const s = Math.min(r.width / vw, r.height / vh);
    const w = vw * s, h = vh * s;
    return { left: r.left + (r.width - w) / 2, top: r.top + (r.height - h) / 2, width: w, height: h };
  }

  function isActive() {
    if (!cfg.enabled || !cfg[SITE]) return false;
    if (SITE === 'youtube') return location.pathname === '/watch';
    return true;
  }

  function setShown(on) {
    if (on === shown) return;
    shown = on;
    canvas.style.display = on ? 'block' : 'none';
    if (on) markFresh();
  }

  // ---------- main loop ----------
  function tick(now) {
    requestAnimationFrame(tick);

    const active = isActive();
    if (active !== wasActive) {
      wasActive = active;
      root.classList.toggle('al-on', active);
    }
    if (!active) return setShown(false);

    const v = pickVideo(now);
    if (!v || document.fullscreenElement) return setShown(false);

    const r = contentRect(v);
    if (r.top > innerHeight || r.top + r.height < 0) return setShown(false);

    const key = [r.left, r.top, r.width, r.height].map((n) => Math.round(n * 2)).join(',');
    if (key !== lastKey) {
      lastKey = key;
      const px = (r.width * cfg.spread) / 100;
      const py = (r.height * cfg.spread) / 100;
      canvas.style.width = r.width + 2 * px + 'px';
      canvas.style.height = r.height + 2 * py + 'px';
      canvas.style.transform = `translate(${r.left - px}px, ${r.top - py}px)`;
      canvas.style.setProperty('--al-hx', px + 'px');
      canvas.style.setProperty('--al-hy', py + 'px');
      canvas.style.setProperty('--al-hw', r.width + 'px');
      canvas.style.setProperty('--al-hh', r.height + 'px');
    }
    setShown(true);

    if (now - lastDraw < 1000 / cfg.fps) return;
    if (v.paused && !dirty) return;
    if (v.readyState < 2 || !v.videoWidth) return;

    lastDraw = now;
    try {
      ctx.globalAlpha = fresh ? 1 : Math.max(0.05, 1 - cfg.smooth / 100);
      ctx.drawImage(v, 0, 0, SW, SH);
      fresh = false;
      dirty = false;
    } catch (_) { /* DRM */ }
  }

  window.addEventListener('yt-navigate-finish', markFresh);
  requestAnimationFrame(tick);
})();